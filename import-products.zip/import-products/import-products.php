<?php
/*
Plugin Name: WooCommerce product Importer
Description: Import WooCommerce product from CSV.
Version: 1.0
Author: Your Name
*/

// Activation hook
register_activation_hook(__FILE__, 'wc_product_importer_activate');

function wc_product_importer_activate() {
    // Activation tasks if any
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wc_product_importer_deactivate');

function wc_product_importer_deactivate() {
    // Deactivation tasks if any
}

// Add admin menu
add_action('admin_menu', 'wc_product_importer_menu');

function wc_product_importer_menu() {
    add_menu_page(
        'Product Importer',
        'Product Importer',
        'manage_options',
        'wc-product-importer',
        'wc_product_importer_page'
    );
}

function wc_product_importer_page() {
    ?>
    <div class="wrap">
        <h2>WooCommerce Category Importer</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="csv_file" />
            <input type="submit" name="import_products" value="Import Products" class="button-primary"/>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'wc_product_importer_handle_form');

function wc_product_importer_handle_form() {
    if (isset($_POST['import_products'])) {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have sufficient permissions to access this page.');
        }

        if (empty($_FILES['csv_file']['tmp_name'])) {
            wp_die('Please upload a CSV file.');
        }

        $csv_data = parse_csv($_FILES['csv_file']['tmp_name']);
        import_products($csv_data);

        echo '<div class="updated"><p>Products imported successfully.</p></div>';
    }
}

function parse_csv($file_path) {
    $csv_data = array();
    if (($handle = fopen($file_path, 'r')) !== FALSE) {
        // Read the first row to get column keys
        $keys = fgetcsv($handle, 1000, ',');
        
        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
            // Combine keys and data to create associative array
            $csv_data[] = array_combine($keys, $data);
        }
        fclose($handle);
    }
    return $csv_data;
}

function import_products($csv_data) {
    foreach ($csv_data as $row) {
        // Assuming CSV format: SKU,Product Name,Category,Price,Meta1,Meta2,Meta3,...
        $sku = $row['rentalClass'];
        $product_name = $row['descLine01'];
        $category_name = $row['category_name'];
        $price = $row['price'];

        // Prepare meta fields
        $meta_fields = array();

        foreach ($row as $key => $value) {
            $meta_key = 'raphael_' . $key;
            // Exclude known fields (SKU, Product Name, Category, Price)
            if (!in_array($key, ['rentalClass', 'descLine01', 'category_name', 'price'])) {
                $meta_fields[$meta_key] = $value;  
            }
        }

        // Check if category exists, if not, create it
        $category = get_term_by('name', $category_name, 'product_cat');
        if (!$category) {
            $category_id = wp_insert_term($category_name, 'product_cat');
            if (is_array($category_id) && isset($category_id['term_id'])) {
                $category_id = $category_id['term_id'];
            }
        } else {
            $category_id = $category->term_id;
        }

        // Prepare product data
        $product_data = array(
            'post_title' => $product_name,
            'post_type' => 'product',
            'post_status' => 'publish',
            'meta_input' => array(
                '_price' => $price,
                '_regular_price' => $price,
                '_sku' => $sku
            )
        );

        // Add category
        if ($category_id) {
            $product_data['tax_input'] = array('product_cat' => array($category_id));
        }

        // Add meta fields
        foreach ($meta_fields as $meta_key => $meta_value) {
            // Use meta_key directly without modification
            $product_data['meta_input'][$meta_key] = $meta_value;
        }

        // Insert product
        $product_id = wp_insert_post($product_data, true);
        if (is_wp_error($product_id)) {
            // Handle error
            echo '<div class="error"><p>Error importing product: ' . $product_id->get_error_message() . '</p></div>';
        } else {
            // Product imported successfully
            echo '<div class="updated"><p>Product imported successfully: ' . $product_name . '</p></div>';

            // Import large image
            $large_image_url = $row['largeImage'];
            if (!empty($large_image_url)) {
                $attachment_id = import_product_image($large_image_url, $product_id);
                if (!is_wp_error($attachment_id)) {
                    set_post_thumbnail($product_id, $attachment_id);
                } else {
                    echo '<div class="error"><p>Error importing large image for product ' . $product_name . ': ' . $attachment_id->get_error_message() . '</p></div>';
                }
            }
        }
    }
}

function import_product_image($image_url, $product_id) {
    $image_name = basename($image_url);
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    $unique_file_name = wp_unique_filename($upload_dir['path'], $image_name);
    $filename = $upload_dir['path'] . '/' . $unique_file_name;
    if (file_put_contents($filename, $image_data)) {
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($image_name),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $filename, $product_id);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $filename);
        wp_update_attachment_metadata($attach_id, $attach_data);
        return $attach_id;
    }
    return new WP_Error('import_error', 'Failed to import image: ' . $image_url);
}
