$(document).ready(function () {

  // navigation class  js here
  $(".navigation-toggler").click(function () {
    $(".closed-navbar").toggleClass("open-navbar");
    $("body").toggleClass("body-active");
  });
  $(".site-header-menu-wrapper-overlay").click(function () {
    $(".closed-navbar.open-navbar").toggleClass("open-navbar");
    $("body").removeClass("body-active");
  });
  // End navigation class  js here

});

$(window).scroll(function () {
  if ($(this).scrollTop() > 1) {
    $('.site-header').addClass("sticky");
  }
  else {
    $('.site-header').removeClass("sticky");
  }
});

/*:: hero-slider carsoul js here  :: */
$('.owl-carousel').owlCarousel({
  loop: true,
  margin: 0,
  dots: false,
  nav: true,
  mouseDrag: false,
  autoplay: true,
  animateOut: 'slideOutUp',
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 1
    },
    1000: {
      items: 1
    }
  }
});




