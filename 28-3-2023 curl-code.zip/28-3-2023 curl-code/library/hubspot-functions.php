<?php
function getHobspottags(){

}

function getHobspottagsid($tagName){
	if($tagName == ""){
		return false;
	}
	return getHobspotCurl('tagid', $tagName);  
}

function getHobspotPostbytagsid($tagid){
    if($tagid == ""){
		return false;
	}
	return getHobspotCurl('blogs', "", $tagid);
}

function getHobspotCurl($pathpart, $tagName = "", $tagid = ""){
	// https://api.hubapi.com/cms/v3/blogs/tags?name=News&state='.$api_state.'
	// https://api.hubapi.com/blogs/v3/blog-posts?tagId='.$tagid.'&state='.$api_state.'
	/*https://api.hubapi.com/cms/v3/blogs/posts?state='.$api_state.'&limit=6&sort=-createdAt&order_by=Ascending'*/
	$api_key = 'pat-na1-0d19c89f-43e5-4647-97c4-3c0734074605';
	$api_state = 'PUBLISHED';
	$base_Path ="https://api.hubapi.com/";
	if($pathpart == 'tagid' && $tagName != ""){
     $base_Path = $base_Path . 'cms/v3/blogs/tags?name='.$tagName;
	}
	elseif($pathpart == 'blogs' && $tagid != ""){
	 $base_Path = $base_Path . 'blogs/v3/blog-posts?tagId='.$tagid.'&limit=6';
	}
	$base_Path = $base_Path . '&state='.$api_state;
	$curl = curl_init();	
	curl_setopt_array($curl, array(
	  CURLOPT_URL => $base_Path,
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'GET',
	  CURLOPT_HTTPHEADER => array(
	    'Authorization: Bearer '.$api_key
	  ),
	));
	$response = curl_exec($curl);
	curl_close($curl);
	return $response;
}

function getHobspotSingleBlogHtml($value){
	$author_name = $created_date = $post_url = $content = $heading = $heading_title =  '';

	  $featured_image = get_template_directory_uri().'/assets/images/thumbnails/placeholder-image.png';

	  if (!empty($value['featuredImage'])) {
	    $featured_image = $value['featuredImage'];
	  }
	  if (isset($value['authorName']) && !empty($value['authorName'])){
	     $author_name = $value['authorName'];
	  }
	  if (isset($value['created']) && !empty($value['created'])){
	     $created_date = $value['created'];
	     $created_date = date("d/m/Y", strtotime($created_date));  
	  }
	  if (isset($value['url']) && !empty($value['url'])) {
	     $post_url = $value['url'];
	  }
	  if (isset($value['htmlTitle']) && !empty($value['htmlTitle'])) {
	     $heading = $value['htmlTitle'];
	     $heading_title = $value['htmlTitle'];
	      $heading = wp_trim_words($heading,10, '...');
	  }
	  if (!empty($value['postBody']) && isset($value['postBody'])) {
	      $content = $value['postBody'];
	      $content = preg_replace("/<img[^>]+\>/i", " ", $content);    $content = apply_filters('the_content', $content);
	      $content = str_replace(']]>', ']]>', $content);
	      $content = wp_trim_words($content, 40, '...');
	  }
	  $output = '<div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="1000">
	      <div class="lending-card">
	        <a  target="_blank" href="'.esc_url($post_url).'"><figure class="lending-fig">
	          <img class="img-scaller" src="'.esc_html__($featured_image).'" alt="HELVETICA CLOSES">
	        </figure></a>
	        <div class="lending-card-content">
	          <ul class="post-widgets">';
	          if (!empty($created_date)) {
	              $output .= '<li class="post-widgets-items">
	              <span class="post-widgets-icon">
	                <img class="" src="'.get_template_directory_uri().'/assets/images/icons/calendar-blue.png" alt="calendar-blue">
	              </span>
	              <span class="post-widgets-text">
	                '.esc_html__($created_date).'
	              </span>
	            </li>';
	            }
	            if (!empty($author_name)) {
	              $output .= '<li class="post-widgets-items">
	              <span class="post-widgets-icon">
	                <img class="" src="'.get_template_directory_uri().'/assets/images/icons/user-blue.png" alt="user-blue">
	              </span>
	              <span class="post-widgets-text">
	               '.esc_html__($author_name).'
	              </span>
	            </li>';
	            }
	          $output .= '</ul>
	          <div class="post-content-wrapper">
	            <h5 class="lending-card-title">
	              <a  target="_blank" href="'.esc_url($post_url).'" title="'.$heading_title.'">
	                '.esc_html($heading).'
	              </a>
	            </h5>
	            <p class="news-press-para">'.$content.'</p>
	            <a  target="_blank" class="read-more-btn" href="'.esc_url($post_url).'">
	              Read more
	            </a>
	          </div>
	        </div>
	      </div>
	    </div>';
	    return $output;

}

 if(!function_exists('getHobspotTagbyblogHtml')){
 	function getHobspotTagbyblogHtml($blogdata, $tagid="") {
 		$data_total = $blogdata['total'];
      $output = ''; 
      $output .= '<section class="investments-section sec-padding">
      <div class="container">
       <div class="lending-wrapper news-press-wrapper blogs-wrapper">
         <div class="blog-section-post"><div class="row">';
      if(!empty($blogdata)){
         foreach ($blogdata as $blogdata_val) {
          if(is_array($blogdata_val)){
           foreach ($blogdata_val as $data_key => $value) {
            if(is_array($value)){
            	$output .= getHobspotSingleBlogHtml($value); 
            }
           }
          }
         }
      }
      $output .= '</div></div>';
      if ($data_total > 6) {
        $output .= '<div class="load_more" data-page="6" data-tag="'.$tagid.'" data-total="'.$data_total.'"><div id="more_posts">Load More</div></div>';
      }
      $output .= '</div></section>';
      return $output;
	}   
 }
