<?php
/* Template Name: test */
get_header();
$response = getHobspottagsid('Advice');
// var_dump($response); 
if(!empty($response)){
  $data = json_decode($response,true);
    if(!empty($data)){
        foreach ( $data as $blog_tag ) {
           /* print_r($blog_tag);*/
         if(is_array($blog_tag)){   
             foreach ( $blog_tag as $blog_tag1 ) {
                $tagid = $blog_tag1['id'];
                $blogdata = '';
                $blogresponse = getHobspotPostbytagsid($tagid);
                if(!empty($blogresponse)){
                  $blogdata = json_decode($blogresponse,true);
                  echo getHobspotTagbyblogHtml($blogdata, $tagid);
                }
             }
         }
        }
    }
}    
get_footer();


