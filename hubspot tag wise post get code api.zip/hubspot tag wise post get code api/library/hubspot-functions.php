<?php
function getHobspottags(){

}

function getHobspottagsid($tagName){
	if($tagName == ""){
		return false;
	}
	return getHobspotCurl('tagid', $tagName);  
}

function getHobspotPostbytagsid($tagid){
    if($tagid == ""){
		return false;
	}
	return getHobspotCurl('blogs', "", $tagid);
}

function getHobspotCurl($pathpart, $tagName = "", $tagid = ""){
	// https://api.hubapi.com/cms/v3/blogs/tags?name=News&state='.$api_state.'
	// https://api.hubapi.com/blogs/v3/blog-posts?tagId='.$tagid.'&state='.$api_state.'
	/*https://api.hubapi.com/cms/v3/blogs/posts?state='.$api_state.'&limit=6&sort=-createdAt&order_by=Ascending'*/
	$api_key = 'pat-na1-0d19c89f-43e5-4647-97c4-3c0734074605';
	$api_state = 'PUBLISHED';
	$base_Path ="https://api.hubapi.com/";
	if($pathpart == 'tagid' && $tagName != ""){
     $base_Path = $base_Path . 'cms/v3/blogs/tags?name='.$tagName;
	}
	elseif($pathpart == 'blogs' && $tagid != ""){
	 $base_Path = $base_Path . 'blogs/v3/blog-posts?tagId='.$tagid;
	}
	$base_Path = $base_Path . '&state='.$api_state;
	$curl = curl_init();	
	curl_setopt_array($curl, array(
	  CURLOPT_URL => $base_Path,
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'GET',
	  CURLOPT_HTTPHEADER => array(
	    'Authorization: Bearer '.$api_key
	  ),
	));
	$response = curl_exec($curl);
	curl_close($curl);
	return $response;
}

/*function getHobspotTagbyblogHtml() {
    if(function_exists('top_header_warpper')){
   
 }
}*/