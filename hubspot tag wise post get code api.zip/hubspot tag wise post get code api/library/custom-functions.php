<?php 
/**
* Add Custom theme options.
*/
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'    => 'Theme Options',
        'menu_title'    => 'Theme Options',
        'menu_slug'     => 'theme-options',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));     
}
/************************************************************
 * Description: Svg image code 
 * Date: 20-12-2022
 * Author: 
 * ********************************************************/
add_filter( 'wp_check_filetype_and_ext', function($data, $file, $filename, $mimes) {
  $filetype = wp_check_filetype( $filename, $mimes );
  return [
      'ext'             => $filetype['ext'],
      'type'            => $filetype['type'],
      'proper_filename' => $data['proper_filename']
  ];
}, 10, 4 );
function cc_mime_types( $mimes ){
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter( 'upload_mimes', 'cc_mime_types' );
function fix_svg() {
        echo '<style type="text/css">
        .attachment-266x266, .thumbnail img {
             width: 100% !important;
             height: auto !important;
        }
        </style>';
}
add_action( 'admin_head', 'fix_svg' );
/************************************************************
 * Description: image field srcset
 * Date: 20-12-2022
 * Author: 
 * ********************************************************/
function awesome_acf_responsive_image($attachment_id,$image_size,$max_width){
    if($attachment_id != '') {
        $img_src = wp_get_attachment_image_url( $attachment_id, $image_size );
        $img_srcset = wp_get_attachment_image_srcset( $attachment_id, '400' );
    ?>
    <img src="<?php echo esc_url( $img_src ); ?>" srcset="<?php echo esc_attr( $img_srcset ); ?>" sizes="(max-width: 50em) 87vw, 680px" alt="Foo Bar" class="img-responsive">
    <?php }
}
add_image_size( 'cover-size', 450, 450, true ); 
//set_post_thumbnail_size( 150, 150 );
/************************************************************/

function more_post_ajax(){

    $ppp = (isset($_POST["ppp"])) ? $_POST["ppp"] : 6;
    $page = (isset($_POST['pageNumber'])) ? $_POST['pageNumber'] : 1;
    $offset = (isset($_POST['offset'])) ? $_POST['offset'] : 1;
    $old_page = $ppp*($page-1);
    $data = array('');
    $curl = curl_init();
    $api_key = 'pat-na1-0d19c89f-43e5-4647-97c4-3c0734074605';
    $api_state = 'PUBLISHED';
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://api.hubapi.com/cms/v3/blogs/posts?state='.$api_state.'&limit='.$ppp.'&offset='.$old_page.'&order_by=Ascending&sort=-createdAt',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HTTPHEADER => array(
        'Authorization: Bearer '.$api_key
      ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
        if(!empty($response)){
              $data = json_decode($response,true);
              $page_count  = $data['total']/6;
              $data = $data['results'];
        }
        $output = '';
        $output1 = '';
            if(!empty($data)){
                $i = $old_page;
             foreach ($data as $data_key => $value) {
                $author_name = $created_date = $post_url = $content = $heading = $heading_title =  '';
                $featured_image = get_template_directory_uri().'/assets/images/thumbnails/placeholder-image.png';
                if (!empty($value['featuredImage'])) {
                  $featured_image = $value['featuredImage'];
                }
                if (isset($value['authorName']) && !empty($value['authorName'])) {
                   $author_name = $value['authorName'];
                }
                 if (isset($value['created']) && !empty($value['created'])) {
                   $created_date = $value['created'];
                   $created_date = date("d/m/Y", strtotime($created_date));  
                }
                 if (isset($value['url']) && !empty($value['url'])) {
                   $post_url = $value['url'];
                }

                if (isset($value['htmlTitle']) && !empty($value['htmlTitle'])) {
                   $heading = $value['htmlTitle'];
                   $heading_title = $value['htmlTitle'];
                    $heading = wp_trim_words($heading,10, '...');
                }
                if (!empty($value['postBody']) && isset($value['postBody'])) {
                    $content = $value['postBody'];
                    $content = preg_replace("/<img[^>]+\>/i", " ", $content);          
                    $content = apply_filters('the_content', $content);
                    $content = str_replace(']]>', ']]>', $content);
                    $content = wp_trim_words($content, 40, '...');
                }
                $output .= '<div class="col-md-6 col-lg-4" data-aos="fade-up '.$i.'" data-aos-duration="1000">
                    <div class="lending-card">
                      <a  target="_blank" href="'.esc_url($post_url).'"><figure class="lending-fig">
                        <img class="img-scaller" src="'.esc_html__($featured_image).'" alt="HELVETICA CLOSES">
                      </figure></a>
                      <div class="lending-card-content">
                        <ul class="post-widgets">';
                          if (!empty($created_date)) {
                            $output .= '<li class="post-widgets-items">
                            <span class="post-widgets-icon">
                              <img class="" src="'.get_template_directory_uri().'/assets/images/icons/calendar-blue.png" alt="calendar-blue">
                            </span>
                            <span class="post-widgets-text">
                              '.esc_html__($created_date).'
                            </span>
                          </li>';
                          }
                          if (!empty($author_name)) {
                            $output .= '<li class="post-widgets-items">
                            <span class="post-widgets-icon">
                              <img class="" src="'.get_template_directory_uri().'/assets/images/icons/user-blue.png" alt="user-blue">
                            </span>
                            <span class="post-widgets-text">
                             '.esc_html__($author_name).'
                            </span>
                          </li>';
                          }
                        $output .= '</ul>

                        <div class="post-content-wrapper">
                          <h5 class="lending-card-title">
                            <a  target="_blank" href="'.esc_url($post_url).'" title="'.$heading_title.'">
                              '.esc_html($heading).'
                            </a>
                          </h5>
                          <p class="news-press-para">
                            '.$content.'
                          </p>
                          <a  target="_blank" class="read-more-btn" href="'.esc_url($post_url).'">
                            Read more
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>';
                  $i++;
                }
              }
              if (empty($output)) {
                  $load_more = '';
              }else{
                $load_more = $old_page;
              }
          echo json_encode(array('message'=>'success','data'=>$output,'load_more'=>$load_more));
          wp_die();
    }

add_action('wp_ajax_nopriv_more_post_ajax', 'more_post_ajax');
add_action('wp_ajax_more_post_ajax', 'more_post_ajax');