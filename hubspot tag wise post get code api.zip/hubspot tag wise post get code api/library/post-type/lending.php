<?php // Transactions CPT
add_action('init', 'helvetica_Lendings');
function helvetica_Lendings()
{
	$labels = array(
		'name'               => _x('Lending', 'post type general name', 'helvetica'),
		'singular_name'      => _x('Lending', 'post type singular name', 'helvetica'),
		'menu_name'          => _x('Lending', 'admin menu', 'helvetica'),
		'name_admin_bar'     => _x('Lending', 'add new on admin bar', 'helvetica'),
		'add_new'            => _x('Add New', 'Lending', 'helvetica'),
		'add_new_item'       => __('Add New Lending', 'helvetica'),
		'new_item'           => __('New Lending', 'helvetica'),
		'edit_item'          => __('Edit Lending', 'helvetica'),
		'view_item'          => __('View Lending', 'helvetica'),
		'all_items'          => __('All Lending', 'helvetica'),
		'search_items'       => __('Search Lending', 'helvetica'),
		'parent_item_colon'  => __('Parent Lending:', 'helvetica'),
		'not_found'          => __('No Lending found.', 'helvetica'),
		'not_found_in_trash' => __('No Lending found in Trash.', 'helvetica')
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __('Description.', 'helvetica'),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'Lending'),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array('title', 'editor', 'thumbnail'),
		'rewrite' => array('slug' => 'lending'),
	);

	register_post_type('lending', $args);
}


/* taxonomy*/
function lending_texonomy_for_cpt_with_varition() {

    register_taxonomy( 'lending_category', 'lending', array(
         'hierarchical' => true,
         'labels' => lending_texonomy_function_for_added_cpt( 'lending category' ),
         'show_ui' => true,
         'show_in_rest' => true,
         'show_admin_column' => true,
         'update_count_callback' => '_update_post_term_count',
         'query_var' => true,
         'rewrite' => array( 'slug' => 'lending-category' ),
    ) );
}
add_action( 'init', 'lending_texonomy_for_cpt_with_varition' );

function lending_texonomy_function_for_added_cpt( $texonomy_title ){
   return array(
       'name' => _x( $texonomy_title, 'taxonomy general name' ),
       'singular_name' => _x( $texonomy_title, 'taxonomy singular name' ),
       'search_items' =>  __( 'Search '.$texonomy_title ),
       'popular_items' => __( 'Popular '.$texonomy_title ),
       'all_items' => __( 'All '.$texonomy_title ),
       'parent_item' => null,
       'parent_item_colon' => null,
       'edit_item' => __( 'Edit '.$texonomy_title ),
       'update_item' => __( 'Update '.$texonomy_title ),
       'add_new_item' => __( 'Add New '.$texonomy_title ),
       'new_item_name' => __( 'New '.$texonomy_title.' Name' ),
       'separate_items_with_commas' => __( 'Separate '.$texonomy_title.' with commas' ),
       'add_or_remove_items' => __( 'Add or remove '.$texonomy_title ),
       'choose_from_most_used' => __( 'Choose from the most used '.$texonomy_title ),
       'menu_name' => __( $texonomy_title ),
     ); 
}
