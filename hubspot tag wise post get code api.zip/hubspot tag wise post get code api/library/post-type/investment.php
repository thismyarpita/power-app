<?php // Transactions CPT
add_action('init', 'helvetica_investment');
function helvetica_investment()
{
	$labels = array(
		'name'               => _x('Investment', 'post type general name', 'helvetica'),
		'singular_name'      => _x('Investment', 'post type singular name', 'helvetica'),
		'menu_name'          => _x('Investment', 'admin menu', 'helvetica'),
		'name_admin_bar'     => _x('Investment', 'add new on admin bar', 'helvetica'),
		'add_new'            => _x('Add New', 'Investment', 'helvetica'),
		'add_new_item'       => __('Add New Investment', 'helvetica'),
		'new_item'           => __('New Investment', 'helvetica'),
		'edit_item'          => __('Edit Investment', 'helvetica'),
		'view_item'          => __('View Investment', 'helvetica'),
		'all_items'          => __('All Investment', 'helvetica'),
		'search_items'       => __('Search Investment', 'helvetica'),
		'parent_item_colon'  => __('Parent Investment:', 'helvetica'),
		'not_found'          => __('No Investment found.', 'helvetica'),
		'not_found_in_trash' => __('No Investment found in Trash.', 'helvetica')
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __('Description.', 'helvetica'),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'investment'),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array('title', 'editor', 'thumbnail'),
		'rewrite' => array('slug' => 'investment-details'),
	);

	register_post_type('investment', $args);
}

/* taxonomy*/
function investment_texonomy_for_cpt_with_varition() {

    register_taxonomy( 'investment_category', 'investment', array(
         'hierarchical' => true,
         'labels' => investment_texonomy_function_for_added_cpt( 'investment category' ),
         'show_ui' => true,
         'show_in_rest' => true,
         'show_admin_column' => true,
         'update_count_callback' => '_update_post_term_count',
         'query_var' => true,
         'rewrite' => array( 'slug' => 'investments' ),
    ) );
}
add_action( 'init', 'investment_texonomy_for_cpt_with_varition' );

function investment_texonomy_function_for_added_cpt( $texonomy_title ){
   return array(
       'name' => _x( $texonomy_title, 'taxonomy general name' ),
       'singular_name' => _x( $texonomy_title, 'taxonomy singular name' ),
       'search_items' =>  __( 'Search '.$texonomy_title ),
       'popular_items' => __( 'Popular '.$texonomy_title ),
       'all_items' => __( 'All '.$texonomy_title ),
       'parent_item' => null,
       'parent_item_colon' => null,
       'edit_item' => __( 'Edit '.$texonomy_title ),
       'update_item' => __( 'Update '.$texonomy_title ),
       'add_new_item' => __( 'Add New '.$texonomy_title ),
       'new_item_name' => __( 'New '.$texonomy_title.' Name' ),
       'separate_items_with_commas' => __( 'Separate '.$texonomy_title.' with commas' ),
       'add_or_remove_items' => __( 'Add or remove '.$texonomy_title ),
       'choose_from_most_used' => __( 'Choose from the most used '.$texonomy_title ),
       'menu_name' => __( $texonomy_title ),
     ); 
}