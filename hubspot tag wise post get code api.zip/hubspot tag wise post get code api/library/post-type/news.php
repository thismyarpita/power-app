<?php // Transactions CPT
add_action('init', 'helvetica_news_transactions');
function helvetica_news_transactions()
{
	$labels = array(
		'name'               => _x('News', 'post type general name', 'helvetica'),
		'singular_name'      => _x('News', 'post type singular name', 'helvetica'),
		'menu_name'          => _x('News', 'admin menu', 'helvetica'),
		'name_admin_bar'     => _x('New', 'add new on admin bar', 'helvetica'),
		'add_new'            => _x('Add New', 'News', 'helvetica'),
		'add_new_item'       => __('Add New News', 'helvetica'),
		'new_item'           => __('New News', 'helvetica'),
		'edit_item'          => __('Edit News', 'helvetica'),
		'view_item'          => __('View News', 'helvetica'),
		'all_items'          => __('All News', 'helvetica'),
		'search_items'       => __('Search News', 'helvetica'),
		'parent_item_colon'  => __('Parent News:', 'helvetica'),
		'not_found'          => __('No News found.', 'helvetica'),
		'not_found_in_trash' => __('No News found in Trash.', 'helvetica')
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __('Description.', 'helvetica'),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'news'),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array('title', 'editor', 'thumbnail'),
		'rewrite' => array('slug' => 'news'),
	);

	register_post_type('news', $args);
}





