<?php // Transactions CPT
add_action('init', 'helvetica_transactions');
function helvetica_transactions()
{
	$labels = array(
		'name'               => _x('Transactions', 'post type general name', 'helvetica'),
		'singular_name'      => _x('Transactions', 'post type singular name', 'helvetica'),
		'menu_name'          => _x('Transactions', 'admin menu', 'helvetica'),
		'name_admin_bar'     => _x('Transactions', 'add new on admin bar', 'helvetica'),
		'add_new'            => _x('Add New', 'Transactions', 'helvetica'),
		'add_new_item'       => __('Add New Transactions', 'helvetica'),
		'new_item'           => __('New Transactions', 'helvetica'),
		'edit_item'          => __('Edit Transactions', 'helvetica'),
		'view_item'          => __('View Transactions', 'helvetica'),
		'all_items'          => __('All Transactions', 'helvetica'),
		'search_items'       => __('Search Transactions', 'helvetica'),
		'parent_item_colon'  => __('Parent Transactions:', 'helvetica'),
		'not_found'          => __('No Transactions found.', 'helvetica'),
		'not_found_in_trash' => __('No Transactions found in Trash.', 'helvetica')
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __('Description.', 'helvetica'),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'transactions'),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array('title', 'editor', 'thumbnail'),
		'rewrite' => array('slug' => 'transactions-details'),
	);

	register_post_type('transactions', $args);
}





