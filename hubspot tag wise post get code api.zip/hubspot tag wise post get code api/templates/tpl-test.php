<?php
/* Template Name: test */
get_header();
$response = getHobspottagsid('Advice');
// var_dump($response); 
if(!empty($response)){
  $data = json_decode($response,true);
    if(!empty($data)){
        foreach ( $data as $blog_tag ) {
           /* print_r($blog_tag);*/
         if(is_array($blog_tag)){   
             foreach ( $blog_tag as $blog_tag1 ) {
                $tagid = $blog_tag1['id'];
                $blogdata = '';
                $blogresponse = getHobspotPostbytagsid($tagid);
                if(!empty($blogresponse)){
                  $blogdata = json_decode($blogresponse,true);
                  $data_total = $blogdata['total'];
                  $output = ''; 
                  $output .= '<section class="investments-section sec-padding">
                  <div class="container">
                   <div class="lending-wrapper news-press-wrapper blogs-wrapper">
                     <div class="blog-section-post"><div class="row">';
                  if(!empty($blogdata)){
                     foreach ($blogdata as $blogdata_val) {
                      if(is_array($blogdata_val)){
                       foreach ($blogdata_val as $data_key => $value) {
                        if(is_array($value)){
                          $author_name = $created_date = $post_url = $content = $heading = $heading_title =  '';

                              $featured_image = get_template_directory_uri().'/assets/images/thumbnails/placeholder-image.png';

                              if (!empty($value['featuredImage'])) {
                                $featured_image = $value['featuredImage'];
                              }
                              if (isset($value['authorName']) && !empty($value['authorName'])){
                                 $author_name = $value['authorName'];
                              }
                              if (isset($value['created']) && !empty($value['created'])){
                                 $created_date = $value['created'];
                                 $created_date = date("d/m/Y", strtotime($created_date));  
                              }
                              if (isset($value['url']) && !empty($value['url'])) {
                                 $post_url = $value['url'];
                              }
                              if (isset($value['htmlTitle']) && !empty($value['htmlTitle'])) {
                                 $heading = $value['htmlTitle'];
                                 $heading_title = $value['htmlTitle'];
                                  $heading = wp_trim_words($heading,10, '...');
                              }
                              if (!empty($value['postBody']) && isset($value['postBody'])) {
                                  $content = $value['postBody'];
                                  $content = preg_replace("/<img[^>]+\>/i", " ", $content);    $content = apply_filters('the_content', $content);
                                  $content = str_replace(']]>', ']]>', $content);
                                  $content = wp_trim_words($content, 40, '...');
                              }
                              $output .= '<div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-duration="1000">
                                  <div class="lending-card">
                                    <a  target="_blank" href="'.esc_url($post_url).'"><figure class="lending-fig">
                                      <img class="img-scaller" src="'.esc_html__($featured_image).'" alt="HELVETICA CLOSES">
                                    </figure></a>
                                    <div class="lending-card-content">
                                      <ul class="post-widgets">';
                                      if (!empty($created_date)) {
                                          $output .= '<li class="post-widgets-items">
                                          <span class="post-widgets-icon">
                                            <img class="" src="'.get_template_directory_uri().'/assets/images/icons/calendar-blue.png" alt="calendar-blue">
                                          </span>
                                          <span class="post-widgets-text">
                                            '.esc_html__($created_date).'
                                          </span>
                                        </li>';
                                        }
                                        if (!empty($author_name)) {
                                          $output .= '<li class="post-widgets-items">
                                          <span class="post-widgets-icon">
                                            <img class="" src="'.get_template_directory_uri().'/assets/images/icons/user-blue.png" alt="user-blue">
                                          </span>
                                          <span class="post-widgets-text">
                                           '.esc_html__($author_name).'
                                          </span>
                                        </li>';
                                        }
                                      $output .= '</ul>
                                      <div class="post-content-wrapper">
                                        <h5 class="lending-card-title">
                                          <a  target="_blank" href="'.esc_url($post_url).'" title="'.$heading_title.'">
                                            '.esc_html($heading).'
                                          </a>
                                        </h5>
                                        <p class="news-press-para">'.$content.'</p>
                                        <a  target="_blank" class="read-more-btn" href="'.esc_url($post_url).'">
                                          Read more
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                </div>';
                        }
                       }
                      }
                     }
                  }
                  $output .= '</div></div>';
                  /*if ($data_total > 6) {
                    $output .= '<div class="load_more" data-page="6" data-total="'.$data_total.'"><div id="more_posts">Load More</div></div>';
                  }*/
        $output .= '  
        </div>
      </section>';
                  echo $output;
                }
             }
         }
        }
    }
}    
get_footer();


