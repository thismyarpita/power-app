<?php
/*
Plugin Name: CSV Term Importer
Description: Import terms from a CSV file and associate them with categories in WordPress.
Version: 1.0
Author: Your Name
*/

// Add a menu item to the admin panel
function csv_term_importer_menu() {
    add_menu_page('CSV Term Importer', 'CSV Importer', 'manage_options', 'csv-term-importer', 'csv_term_importer_page', 'dashicons-upload');
}
add_action('admin_menu', 'csv_term_importer_menu');

// Callback function to display the importer page
function csv_term_importer_page() {
    ?>
    <div class="wrap">
        <h1>CSV Term Importer</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv"><br><br>
            <input type="submit" name="csv_term_import_submit" value="Import CSV" class="button button-primary">
        </form>
        <?php
        // Process CSV file
        if (isset($_POST['csv_term_import_submit'])) {
            if (isset($_FILES['csv_file']) && !empty($_FILES['csv_file']['tmp_name'])) {
                $csv_file = $_FILES['csv_file']['tmp_name'];
                $csv_data = array_map('str_getcsv', file($csv_file));
                $header = array_shift($csv_data);

                // Assuming your CSV columns are in the following order
                $id_index = array_search('id', $header);
                $name_index = array_search('name', $header);
                $image_index = array_search('image', $header);
                $description_index = array_search('description', $header);
                $parent_id_index = array_search('parentId', $header);

                foreach ($csv_data as $row) {
                   /* print_r($row); die();*/
                    $term_name = $row[$name_index];
                    $existing_term = term_exists_by_name($term_name, 'product_cat'); // Replace 'product_cat' with the actual taxonomy name
                     /*print_r( $existing_term); die();*/
                    if (!$existing_term) {
                        // Term doesn't exist, insert it
                        $term_data = array(
                            'description' => $row[$description_index],
                            // 'raphaels_parent' => $row[$parent_id_index], // Assuming this is the parent term ID
                        );

                        $term_id = wp_insert_term($term_name, 'product_cat', $term_data); // Replace 'product_cat' with the actual taxonomy name

                        if (is_array($term_id) && isset($term_id['term_id'])) {
                            // Term inserted successfully, you can now update meta or do additional operations if needed
                            // Insert image or any other data associated with the term
                            update_term_meta($term_id['term_id'], 'raphaels_image', $row[$image_index]); // Assuming 'image' is the meta key
                            update_term_meta($term_id['term_id'], 'raphaels_category_id', $row[$id_index]); // Assuming 'category_id' is the meta key for 
                            update_term_meta($term_id['term_id'], 'raphaels_parent', $row[$parent_id_index]);
                        }
                    } else {
                        // Term already exists, you may update it if needed
                        // Update description or any other field if necessary
                        wp_update_term($existing_term->term_id, 'product_cat', array(
                            'description' => $row[$description_index],
                            //'raphaels_parent' => $row[$parent_id_index], // Assuming this is the parent term ID
                        ));

                        // Update image and category ID
                        update_term_meta($existing_term->term_id, 'raphaels_image', $row[$image_index]); // Assuming 'image' is the meta key
                        update_term_meta($existing_term->term_id, 'raphaels_category_id', $row[$id_index]); // Assuming 'category_id' is the meta key for category ID
                        update_term_meta($existing_term->term_id, 'raphaels_parent', $row[$parent_id_index]);
                    }
                }
                echo '<div class="updated"><p>CSV file imported successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Please select a CSV file to import.</p></div>';
            }
        }
        ?>
    </div>
    <?php
}

// Function to check if a term exists by name
function term_exists_by_name($term_name, $taxonomy) {
    $term = get_term_by('name', $term_name, $taxonomy);
    if ($term && !is_wp_error($term)) {
        return $term;
    }
    return false;
}